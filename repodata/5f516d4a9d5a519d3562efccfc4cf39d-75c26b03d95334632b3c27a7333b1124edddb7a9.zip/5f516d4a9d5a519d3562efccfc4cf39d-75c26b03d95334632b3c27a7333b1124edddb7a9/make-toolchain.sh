#!/bin/sh

# Please install non-optional dependencies noted on this site:
# https://wiki.osdev.org/GCC_Cross-Compiler

# Compiler Configuration
CROSS_TARGET=x86_64-elf
GCC_VERSION="8.1.0" # GCC version
BIN_VERSION="2.30"  # Binutils version

# Build Configuration
MAKE_JOBS=4
INSTALL_PATH="$HOME/opt/cross-x64"
TOOLCHAIN_DIR=$PWD # needs to be absolute
TOOLCHAIN_SRC=$TOOLCHAIN_DIR/src
TOOLCHAIN_GCC_BUILD_DIR=$TOOLCHAIN_DIR/build-gcc
TOOLCHAIN_BIN_BUILD_DIR=$TOOLCHAIN_DIR/build-binutils

GCC_PKG_NAME="gcc-$GCC_VERSION"
BIN_PKG_NAME="binutils-$BIN_VERSION"

GCC_SRC="https://ftp.gnu.org/gnu/gcc/$GCC_PKG_NAME/$GCC_PKG_NAME.tar.gz" # GCC download link
BIN_SRC="https://ftp.gnu.org/gnu/binutils/$BIN_PKG_NAME.tar.gz"          # Binutils download link

# create source dir, clear its contents
mkdir -p $TOOLCHAIN_SRC
cd $TOOLCHAIN_SRC
touch surpress_warning
rm -r *

# download sources
echo "--> [STATUS] downloading sources..."
#if [ ! -f $PWD/$GCC_PKG_NAME.tar.gz ]; then
wget $GCC_SRC
#fi
#if [ ! -f $PWD/$BIN_PKG_NAME.tar.gz ]; then
wget $BIN_SRC
#fi

# is this needed?
export PATH="$INSTALL_PATH/bin:$PATH"

# unpack source archives
echo "--> [STATUS] unpacking archives..."
#if [ ! -d $PWD/$GCC_PKG_NAME ]; then
tar -zxvf $GCC_PKG_NAME.tar.gz
#fi
#if [ ! -d $PWD/$BIN_PKG_NAME ]; then
tar -zxvf $BIN_PKG_NAME.tar.gz
#fi

# build binutils
mkdir -p $TOOLCHAIN_BIN_BUILD_DIR
cd $TOOLCHAIN_BIN_BUILD_DIR
rm -r *
$TOOLCHAIN_SRC/$BIN_PKG_NAME/configure --target=$CROSS_TARGET --prefix="$INSTALL_PATH" --with-sysroot --disable-nls --disable-werror
make -j$MAKE_JOBS
make install

# build gcc
mkdir -p $TOOLCHAIN_GCC_BUILD_DIR
cd $TOOLCHAIN_GCC_BUILD_DIR
rm -r *
$TOOLCHAIN_SRC/$GCC_PKG_NAME/configure --target=$CROSS_TARGET --prefix="$INSTALL_PATH" --disable-nls --enable-languages=c,c++ --without-headers
make all-gcc -j$MAKE_JOBS
make all-target-libgcc -j$MAKE_JOBS
make install-gcc
make install-target-libgcc

echo "--> [STATUS] DONE!"